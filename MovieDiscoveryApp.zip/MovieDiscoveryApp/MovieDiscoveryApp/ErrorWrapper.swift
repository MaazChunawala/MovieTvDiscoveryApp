import Foundation

struct ErrorWrapper: Identifiable {
    let id = UUID()
    let message: String
}
