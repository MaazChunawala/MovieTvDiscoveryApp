import SwiftUI

@main
struct MovieDiscoveryAppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
